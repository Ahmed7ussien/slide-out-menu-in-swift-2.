//
//  MainNavigationController.swift
//  slideout
//
//  Created by Dennis Suratna on 8/8/15.
//  Copyright (c) 2015 Dennis Suratna. All rights reserved.
//

import UIKit

class MainNavigationController: UINavigationController {

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
       // addObservers()
    }

}
