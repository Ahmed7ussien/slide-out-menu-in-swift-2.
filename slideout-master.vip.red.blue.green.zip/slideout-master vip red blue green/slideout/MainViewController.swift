//
//  MainViewController.swift
//  slideout
//
//  Created by Dennis Suratna on 8/7/15.
//  Copyright (c) 2015 Dennis Suratna. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    
    var menuShown: Bool = false
    
    
    
   @IBAction func menu(sender: AnyObject) {
        
        if(menuShown){
        
            
            
            
            
            UIView.animateWithDuration(0.3, animations: {
                self.view.frame = CGRect(x: 0, y: self.view.frame.origin.y, width: self.view.frame.width, height: self.view.frame.height)
                self.navigationController?.navigationBar.frame =  CGRect(x: self.view.frame.origin.x , y: self.view.frame.origin.y+20, width: (self.navigationController?.navigationBar.frame.width)! , height: (self.navigationController?.navigationBar.frame.height)!)
                }, completion: { (Bool) -> Void in
                    self.menuShown = false
            })
            
            
            
        }else{
            
            
            
            UIView.animateWithDuration(0.3, animations: {
                self.view!.frame = CGRect(x: self.view.frame.origin.x + 100, y: self.view.frame.origin.y, width: self.view.frame.width, height: self.view.frame.height)
            self.navigationController?.navigationBar.frame =  CGRect(x: self.view.frame.origin.x , y: self.view.frame.origin.y+20, width: (self.navigationController?.navigationBar.frame.width)! , height: (self.navigationController?.navigationBar.frame.height)!)
                }, completion: { (Bool) -> Void in
                    self.menuShown = true
            })
            
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
    }

}
